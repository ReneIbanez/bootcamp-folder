
alert("yoooooo");


$(".chicken,.pig,.dog,.cow,.shark").on("click",function(){
  var animalTop = (Math.random()*600);
  var animalLeft =(Math.random()*600);
  $(this).css("marginTop",animalTop);
  $(this).css("marginLeft",animalLeft);
});

$(".chicken").on("click", function (){
  $(".audio1")[0].play();
});

$(".pig").on("click", function (){
  $(".audio2")[0].play();
});

$(".dog").on("click", function (){
  $(".audio3")[0].play();
});

$(".cow").on("click", function (){
  $(".audio4")[0].play();
});

$(".shark").on("click", function (){
  $(".audio5")[0].play();
});

























// 5 animals
//
// document.getElementsByClassName('chicken')[0].onclick=chickenMove;
// document.getElementsByClassName('dog')[0].onclick=dogMove;
// document.getElementsByClassName('pig')[0].onclick=pigMove;
// // ?document.getElementsByClassName('crackhead')[0].onclick=crackheadMove;
// document.getElementsByClassName('cow')[0].onclick=cowMove;
// document.getElementsByClassName('shark')[0].onclick=sharkMove;
//
//
//
//
//
// // this fuunction controls the chicken sound and movement
// function chickenMove(){
//   var goTop = Math.floor(Math.random() * 300);
//   var goLeft = Math.round(Math.random()*300);
//   document.getElementsByClassName('chicken')[0].style.left = goLeft +"px";
//   document.getElementsByClassName('chicken')[0].style.top = goTop +"px";
//   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/soundfx/009/chicken-2.wav';
//   document.getElementsByClassName('audio')[0].play();
//   }
//
//
// // this fuunction controls the Dogs sound and movement
// function dogMove(){
//   var goTop = Math.floor(Math.random() * 300);
//   var goLeft = Math.round(Math.random()*300);
//   document.getElementsByClassName('dog')[0].style.left = goLeft +"px";
//   document.getElementsByClassName('dog')[0].style.top = goTop +"px";
//   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/soundfx/001/dog-bark1.wav';
//   document.getElementsByClassName('audio')[0].play();
//
// }
// // this fuunction controls the Pig sound and movement
// function pigMove() {
//   var goTop = Math.floor(Math.random() * 300);
//   var goLeft = Math.round(Math.random()*300);
//   document.getElementsByClassName('pig')[0].style.left = goLeft +"px";
//   document.getElementsByClassName('pig')[0].style.top = goTop +"px";
//   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/soundfx/016/pig-4.wav';
//   document.getElementsByClassName('audio')[0].play();
//
// }
//
// // this fuunction controls the Crackhead sound and movement
// // function crackheadMove() {
// //   var goTop = Math.floor(Math.random() * 300);
// //   var goLeft = Math.round(Math.random()*300);
// //   document.getElementsByClassName('crackhead')[0].style.left = goLeft +"px";
// //   document.getElementsByClassName('crackhead')[0].style.top = goTop +"px";
// //   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/soundfx/003/cow-madcow.wav';
// //   document.getElementsByClassName('audio')[0].play();
// // }
//
//
// // this fuunction controls the Cow sound and movement
// function cowMove(){
//   var goTop = Math.floor(Math.random() * 300);
//   var goLeft = Math.round(Math.random()*300);
//   document.getElementsByClassName('cow')[0].style.left = goLeft +"px";
//   document.getElementsByClassName('cow')[0].style.top = goTop +"px";
//   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/soundfx/003/cow-moo1.wav';
//   document.getElementsByClassName('audio')[0].play();
// }
//
// function sharkMove(){
//   var goTop = Math.floor(Math.random() * 300);
//   var goLeft = Math.round(Math.random()*300);
//   document.getElementsByClassName('shark')[0].style.left = goLeft +"px";
//   document.getElementsByClassName('shark')[0].style.top = goTop +"px";
//   document.getElementsByClassName('audio')[0].src= 'http://www.wavlist.com/movies/331/jaws-boat.wav';
//   document.getElementsByClassName('audio')[0].play();
//
//
//
// }
//
//
//
//
//
//
//
//
// // all have to make there own noise when cliclked on
//
//
//
//
//
// // each noise is disinctive to each animals

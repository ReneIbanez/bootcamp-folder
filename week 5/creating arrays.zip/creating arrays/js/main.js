
// var images =  ["image1.png","image2.png","image3.png"];
//
// var q2 = images[0];
//
// var q3= images.length;
//
// var q4= images[images.lenth-1];
// var studentnames["jeff","jim","john","jerry","jean"];
// studentnames.foreach[(function("cool,lava"))]
var studentNames=[];

$("#add").on("click", function(){
 $("#input").each(function(){
studentNames.push($(this).val());
 $("#input").val("");

// to reset the box
});

});
$("#print").on("click", function(){
studentNames.forEach(function(a){
$("ol").append("<li>"+a+"</li>");
 studentNames=[];


});


});

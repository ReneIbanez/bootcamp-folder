$(document).ready(function(){
  $('.hamburger').on("click", function() {
 $('header ul,header ul li').toggleClass('ulNone');

 });
});

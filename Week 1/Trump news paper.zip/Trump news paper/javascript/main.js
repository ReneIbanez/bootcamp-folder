$(document).ready(function(){
  $('.hamburger').on("click", function() {
   $('.mobile-nav').toggle();
     $("nav").on("click",function(){})
 })
})








































});
